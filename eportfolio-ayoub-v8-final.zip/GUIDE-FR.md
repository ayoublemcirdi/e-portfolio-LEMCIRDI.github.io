# E-portfolio Ayoub Lemcirdi — version finale V8

## Ouvrir
Télécharger **EPORTFOLIO-OUVRIR.html** et double-cliquer dessus : Chrome ou Edge ouvre le portfolio sans dossier supplémentaire. Les liens internes et les trois PDF sont intégrés dans ce fichier.

## Navigation
Les boutons de l’accueil ouvrent les pages Projets, Compétences, Parcours, Mobilité, Expériences, Engagement, Sports et Contact. FR / EN en haut à droite change la langue sur **toutes les pages**. Une page Mobilité détaille arabe (natif), français C2, anglais C1, allemand B2 et les projets d’études internationaux.

## Documents
Les deux CV (FR, EN) sont corrigés et disponibles depuis l’accueil ou la page Contact. La photo est intégrée correctement au CV anglais. Le TIPE public est disponible dans la fiche TIPE. Les trois PDF existent également séparément dans `assets/` du ZIP.

## Publication GitHub Pages
Dans le dépôt public `ayoublemcirdi.github.io`, importer **index.html** à la racine, puis activer Settings → Pages → Deploy from a branch → main → /(root). Les PDF fonctionnent aussi directement depuis le HTML autonome. Pour disposer des PDF séparés sur GitHub, importer également le dossier `assets/`.

## Confidentialité
Le portfolio contient la photo, le téléphone, l’e-mail, LinkedIn et Instagram qui seront publics après publication. Les deux CV publics mentionnent uniquement Toulouse, sans adresse postale exacte. Le TIPE public masque le numéro d’inscription. Les niveaux de langue sont ceux déclarés par l’utilisateur ; aucune certification n’est présentée comme acquise. Le double diplôme IA / finance est décrit comme un **projet**, non comme une formation déjà suivie.
