Ayoub Lemcirdi | E-portfolio V8 final: single-file bilingual FR/EN website with working internal pages, international mobility, Instagram, and corrected FR/EN PDFs. Read GUIDE-FR.md.
